﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToolApp.BLL.DTO
{
    public class Tool_TypeDTO
    {
        public int Id { get; set; }
        public string Name_tool_type { get; set; } //Название типа инструмента
    }
}
